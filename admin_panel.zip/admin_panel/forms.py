from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.core.exceptions import ValidationError

from core.models import Center, Course, User


class CourseAdminForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = [
            "title", "slug", "description", "category", "mode", "instructor",
            "price", "discounted_price", "center", "thumbnail", "status",
            "requires_instructor_approval",
        ]
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter course title"}),
            "slug": forms.TextInput(attrs={"class": "form-control", "placeholder": "course-slug"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 6, "placeholder": "Enter course description"}),
            "category": forms.TextInput(attrs={"class": "form-control", "placeholder": "Course category"}),
            "mode": forms.Select(attrs={"class": "form-select"}),
            "instructor": forms.Select(attrs={"class": "form-select"}),
            "price": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": "0"}),
            "discounted_price": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": "0"}),
            "center": forms.Select(attrs={"class": "form-select"}),
            "thumbnail": forms.ClearableFileInput(attrs={"class": "form-control", "accept": "image/*"}),
            "status": forms.Select(attrs={"class": "form-select"}),
            "requires_instructor_approval": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["instructor"].queryset = User.objects.filter(
            role=User.Role.INSTRUCTOR, is_active=True
        ).order_by("first_name", "last_name", "username")
        self.fields["center"].queryset = Center.objects.filter(is_active=True).order_by("name")
        self.fields["instructor"].required = False
        self.fields["center"].required = False
        self.fields["thumbnail"].required = False

    def clean_slug(self):
        slug = self.cleaned_data["slug"].strip().lower()
        if not slug:
            raise forms.ValidationError("Course slug is required.")
        return slug

    def clean(self):
        cleaned_data = super().clean()
        mode = cleaned_data.get("mode")
        price = cleaned_data.get("price")
        discounted_price = cleaned_data.get("discounted_price")
        center = cleaned_data.get("center")
        if discounted_price is not None and price is not None and discounted_price > price:
            self.add_error("discounted_price", "Discounted price cannot be greater than the course price.")
        if mode == Course.Mode.OFFLINE and center is None:
            self.add_error("center", "A center is required for an offline course.")
        return cleaned_data


# Only these non-privileged roles may be assigned through this UI.
MANAGEABLE_ROLE_CHOICES = tuple(
    choice for choice in User.Role.choices if choice[0] != User.Role.ADMIN
)


class UserAdminFormBase(forms.ModelForm):
    role = forms.ChoiceField(choices=MANAGEABLE_ROLE_CHOICES, widget=forms.Select(attrs={"class": "form-select"}))

    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "email", "phone", "role", "bio", "profile_photo")
        widgets = {
            "username": forms.TextInput(attrs={"class": "form-control", "autocomplete": "off"}),
            "first_name": forms.TextInput(attrs={"class": "form-control", "autocomplete": "given-name"}),
            "last_name": forms.TextInput(attrs={"class": "form-control", "autocomplete": "family-name"}),
            "email": forms.EmailInput(attrs={"class": "form-control", "autocomplete": "email"}),
            "phone": forms.TextInput(attrs={"class": "form-control", "autocomplete": "tel"}),
            "bio": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
            "profile_photo": forms.ClearableFileInput(attrs={"class": "form-control", "accept": "image/*"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        qs = User.objects.filter(username__iexact=username)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError("A user with this username already exists.")
        return username

    def clean_email(self):
        email = self.cleaned_data.get("email", "").strip()
        if email:
            qs = User.objects.filter(email__iexact=email)
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise ValidationError("A user with this email address already exists.")
        return email


class UserAdminCreateForm(UserAdminFormBase):
    password1 = forms.CharField(label="Password", strip=False, widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}))
    password2 = forms.CharField(label="Confirm password", strip=False, widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}))

    class Meta(UserAdminFormBase.Meta):
        fields = UserAdminFormBase.Meta.fields

    def clean(self):
        cleaned = super().clean()
        password1 = cleaned.get("password1")
        password2 = cleaned.get("password2")
        if password1 and password2 and password1 != password2:
            self.add_error("password2", "The passwords do not match.")
        if password1:
            try:
                password_validation.validate_password(password1, self.instance)
            except ValidationError as exc:
                self.add_error("password1", exc)
        return cleaned

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        # Never accept privilege flags from submitted POST data.
        user.is_superuser = False
        user.is_staff = False
        user.is_active = True
        if commit:
            user.save()
            self.save_m2m()
        return user


class UserAdminUpdateForm(UserAdminFormBase):
    class Meta(UserAdminFormBase.Meta):
        fields = UserAdminFormBase.Meta.fields

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["profile_photo"].required = False
